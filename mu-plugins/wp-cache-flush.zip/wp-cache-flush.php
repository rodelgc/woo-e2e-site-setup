<?php
/**
 * Plugin name: wp_cache_flush
 * Description: Flush cache for E2E test runs.
 *
 * @package Automattic\WooCommerce\E2EPlaywright
 */

wp_cache_flush();
